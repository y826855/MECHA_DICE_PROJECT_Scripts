using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CUI_WeekQueue : MonoBehaviour
{
    public int m_CountOfDays = 5;
    public int m_CurrDay = 0;

    //�̸� �غ�� ť. event day�� �̸� ��ġ�Ǿ� �ִ�.
    public List<string> m_WeekQueue = new List<string>();


    public Dictionary<int, CUI_Day_Holder> m_DayHolders = new Dictionary<int, CUI_Day_Holder>();

    public void ReadyToSet(CUI_Day_Holder _pref)
    {
        for (int i = 0; i < m_CountOfDays; i++)
        {
            var inst = Instantiate(_pref, this.transform);
            m_DayHolders.Add(i, inst);
        }
    }

    public bool CheckIsFull() 
    {
        foreach (var it in m_DayHolders)
            if (it.Value.m_UI_EventDay == null) return false;
        return true;
    }

    public void AddDay(CUI_Event_Day _ui) 
    {
        foreach (var it in m_DayHolders) 
        {
            if (it.Value.m_UI_EventDay == null) 
            {
                it.Value.m_UI_EventDay = _ui;
                _ui.transform.SetParent(it.Value.transform);
                _ui.transform.localPosition = Vector3.zero;
                break;
            }
        }
    }
}
