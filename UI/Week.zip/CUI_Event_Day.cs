using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class CUI_Event_Day : MonoBehaviour
{
    public CScriptable_SceneInfo m_SceneInfo = null;

    public Selectable m_Self = null;
    public Image m_Icon = null;
    public Image m_Frame = null;
    public TextMeshProUGUI m_TMP_TypeName;

    [Header("==========================")]
    public int m_ID = -1;
    public bool m_IsInQueue = false;

    public CUI_Edit_Week m_EditWeek = null;



    public void SetData(CScriptable_SceneInfo _info, int _id) 
    {
        m_SceneInfo = _info;
        m_Icon.sprite = _info.m_SP_Icon;
        m_TMP_TypeName.text = _info.m_Data.m_Name;
        m_ID = _id;

    }

    public void OnClick_Event() 
    {
        if (m_IsInQueue == false) m_EditWeek.AddToWeek(this);
        else m_EditWeek.ReturnToBag(this);
    }
}
