using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CUI_Day_Bag : MonoBehaviour
{
    public CUI_Edit_Week m_EditWeek = null;
    public int m_StartIdx = 0;
    public int m_MaxHolder = 7;

    //�غ�� ���� ������
    //public List<CScriptable_SceneInfo> m_DaysInfo = new List<CScriptable_SceneInfo>();

    //���� UI ����
    public List<CUI_Event_Day> m_UI_Days = new List<CUI_Event_Day>();

    //Ȧ�� ����
    public Dictionary<int, CUI_Day_Holder> m_DayHolders = new Dictionary<int, CUI_Day_Holder>();
    
    
    public virtual void ReadyToSet(CUI_Event_Day _pref_UI_Day, CUI_Day_Holder _pref_Holder)
    {
        var daysInfo = CGameManager.Instance.m_PlayerData.m_DaysBag;

        for (int i = 0; i < m_MaxHolder; i++) 
        {
            var instHolder = Instantiate(_pref_Holder, this.transform);
            int id = m_StartIdx + i;

            if (daysInfo.Count > i)
            {
                var instDay = Instantiate(_pref_UI_Day, instHolder.transform);
                instDay.m_EditWeek = m_EditWeek;
                instDay.SetData(daysInfo[i], id);
                m_UI_Days.Add(instDay);
            }
            m_DayHolders.Add(id, instHolder);
        }
    }

    public void GetBack_Day(CUI_Event_Day _ui) 
    {
        _ui.transform.SetParent(m_DayHolders[_ui.m_ID].transform);
        _ui.transform.localPosition = Vector3.zero;
    }

    public void BuyDay() 
    {
        //TODO 
    }
    public void SellDay(CUI_Day_Holder _holder) 
    {
        var info = _holder.m_UI_EventDay.m_SceneInfo;

        m_UI_Days.Remove(_holder.m_UI_EventDay);
        CGameManager.Instance.m_PlayerData.m_DaysBag.Remove(info);

        Destroy(_holder.m_UI_EventDay.gameObject);
        _holder.m_UI_EventDay = null;

        _holder.Display_Buy();
    }
}
