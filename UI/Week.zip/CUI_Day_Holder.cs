using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CUI_Day_Holder : MonoBehaviour
{
    public CUI_Event_Day m_UI_EventDay = null;

    public bool m_IsDone = false;
    public GameObject m_Cover = null;

    public UnityEngine.UI.Button m_Btn_BuyOrSell = null;
    public TMPro.TextMeshProUGUI m_TMP_BtnText = null;

    public CUI_Edit_Week m_EditWeek = null;

    public void EventDone() 
    {
        m_IsDone = true;
        m_Cover.SetActive(true);
        m_UI_EventDay.m_Self.interactable = false;
    }

    public void SetBtn(bool _isBuyable = false)
    {
        m_Btn_BuyOrSell.gameObject.SetActive(_isBuyable);

    }

    public void Display_Sell() 
    {
        m_TMP_BtnText.text = string.Format("SELL {0}", m_UI_EventDay.m_SceneInfo.m_Data.m_Cost);
    }
    public void Display_Buy() 
    {
        m_TMP_BtnText.text = string.Format("BUY {0}", m_EditWeek.m_DayBuyCost);
    }

    public void OnClick_BuyOrSell() 
    {
        if (m_UI_EventDay == null)
        { }
        else 
        { m_EditWeek.m_UserBag.SellDay(this); }
    }

}
