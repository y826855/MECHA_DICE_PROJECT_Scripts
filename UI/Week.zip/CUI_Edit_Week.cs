using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CUI_Edit_Week : MonoBehaviour
{
    public CUI_Day_Bag m_DefaultBag = null;
    public CUI_Day_Bag m_UserBag = null;
    public CUI_WeekQueue m_Week = null;

    [Header("================")]
    public CUI_Event_Day m_Pref_Day = null;
    public CUI_Day_Holder m_Pref_Holder = null;

    public int m_DayBuyCost = 10;

    public void Start()
    {
        m_DefaultBag.m_EditWeek = this;
        m_UserBag.m_EditWeek = this;

        m_DefaultBag.ReadyToSet(m_Pref_Day, m_Pref_Holder);
        m_UserBag.ReadyToSet(m_Pref_Day, m_Pref_Holder);
        m_Week.ReadyToSet(m_Pref_Holder);
    }

    public void AddToWeek(CUI_Event_Day _ui) 
    {
        if (m_Week.CheckIsFull() == true) return;

        _ui.m_IsInQueue = true;
        m_Week.AddDay(_ui);
    }

    public void ReturnToBag(CUI_Event_Day _ui) 
    {
        _ui.m_IsInQueue = false;
        m_Week.m_DayHolders[_ui.transform.parent.GetSiblingIndex()].m_UI_EventDay = null;

        if (m_DefaultBag.m_DayHolders.Count + m_DefaultBag.m_StartIdx > _ui.m_ID)
        { m_DefaultBag.GetBack_Day(_ui); }
        else
        { m_UserBag.GetBack_Day(_ui); }
    }
}
